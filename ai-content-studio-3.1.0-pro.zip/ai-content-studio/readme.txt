=== AI Content Studio for WordPress ===
Contributors: uaserver
Tags: ai, seo, content, articles, groq, pexels, pixabay, unsplash, rank math, yoast
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 3.1.0
License: GPLv2 or later

AI Content Studio creates SEO article clusters with natural Ukrainian text, thematic free images, FAQ, Schema.org, Rank Math and Yoast metadata, internal links and quality checks.

== Description ==
AI Content Studio for WordPress is a professional AI content generator for WordPress.

Features:
* Article outline before writing
* Natural Ukrainian content without typical AI style
* Topic clusters / content series
* Pexels -> Pixabay -> Unsplash image search without random fallback images
* Automatic English image keyword translation
* Featured image and inline images
* ALT, title and captions for images
* Image optimization
* FAQ block and FAQ Schema
* Article Schema.org
* Rank Math and Yoast SEO fields
* Tags and categories
* Internal linking between generated posts
* Tables, lists, pros/cons blocks, TOC
* Quality score
* Free limit: 20 articles
* Payhip-ready monetization
* GitHub auto-updates through releases

== Installation ==
1. Upload the ZIP in WordPress admin: Plugins -> Add New -> Upload Plugin.
2. Activate the plugin.
3. Go to AI Content Studio -> Settings.
4. Add Groq API key.
5. Recommended: add Pexels API key. Pixabay and Unsplash are fallback providers.
6. Generate first test article as Draft.

== Frequently Asked Questions ==
= Is it free? =
The plugin supports a free limit of 20 generated articles. Pro licensing is prepared for Payhip.

= Are image APIs paid? =
Pexels, Pixabay and Unsplash have free API options. You need your own keys.

= Does localhost count as a licensed domain? =
No. localhost/local/test domains are ignored by the built-in domain counter.

== Changelog ==
= 3.1.0 =
* New professional product direction: AI Content Studio for WordPress.
* Added content clusters, outline, natural text prompt, FAQ, Schema, Rank Math/Yoast, image module, quality score, internal linking, logs, license UI.
