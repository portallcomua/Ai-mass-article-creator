<?php
if (!defined('ABSPATH')) exit;

class AICS_Admin {
    private $generator; private $license;
    public function __construct($generator, $license) {
        $this->generator = $generator; $this->license = $license;
        add_action('admin_menu', array($this, 'menu'));
        add_action('admin_enqueue_scripts', array($this, 'assets'));
        add_action('admin_init', array($this, 'save_settings'));
        add_action('admin_post_aics_activate_license', array($this, 'activate_license'));
    }

    public function menu() {
        add_menu_page('AI Content Studio', 'AI Content Studio', 'manage_options', 'ai-content-studio', array($this, 'page_dashboard'), 'dashicons-edit-page', 20);
        add_submenu_page('ai-content-studio', 'Generator', 'Generator', 'manage_options', 'aics-generator', array($this, 'page_generator'));
        add_submenu_page('ai-content-studio', 'Settings', 'Settings', 'manage_options', 'aics-settings', array($this, 'page_settings'));
        add_submenu_page('ai-content-studio', 'License', 'License', 'manage_options', 'aics-license', array($this, 'page_license'));
        add_submenu_page('ai-content-studio', 'Logs', 'Logs', 'manage_options', 'aics-logs', array($this, 'page_logs'));
    }

    public function assets($hook) {
        if (strpos($hook, 'ai-content-studio') === false && strpos($hook, 'aics-') === false) return;
        wp_enqueue_style('aics-admin', AICS_URL . 'assets/css/admin.css', array(), AICS_VERSION);
        wp_enqueue_script('aics-admin', AICS_URL . 'assets/js/admin.js', array('jquery'), AICS_VERSION, true);
        wp_localize_script('aics-admin', 'AICS', array('ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('aics_admin')));
    }

    public function save_settings() {
        if (!isset($_POST['aics_save_settings']) || !check_admin_referer('aics_save_settings')) return;
        if (!current_user_can('manage_options')) wp_die('Forbidden');
        $keys = array('aics_groq_key','aics_groq_model','aics_pexels_key','aics_pixabay_key','aics_unsplash_key','aics_payhip_url','aics_price_hint','aics_github_repo','aics_image_provider_order');
        foreach ($keys as $key) update_option($key, isset($_POST[$key]) ? sanitize_text_field(wp_unslash($_POST[$key])) : '', false);
        update_option('aics_default_category', isset($_POST['aics_default_category']) ? intval($_POST['aics_default_category']) : 0, false);
        update_option('aics_post_status', isset($_POST['aics_post_status']) ? sanitize_key($_POST['aics_post_status']) : 'draft', false);
        update_option('aics_auto_categories', !empty($_POST['aics_auto_categories']) ? 1 : 0, false);
        update_option('aics_free_limit', isset($_POST['aics_free_limit']) ? intval($_POST['aics_free_limit']) : 20, false);
        update_option('aics_license_domains_limit', isset($_POST['aics_license_domains_limit']) ? intval($_POST['aics_license_domains_limit']) : 3, false);
        wp_redirect(admin_url('admin.php?page=aics-settings&saved=1')); exit;
    }

    public function activate_license() {
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'aics_license')) wp_die('Security check failed');
        if (!current_user_can('manage_options')) wp_die('Forbidden');
        $key = isset($_POST['license_key']) ? sanitize_text_field(wp_unslash($_POST['license_key'])) : '';
        $res = $this->license->activate($key);
        $arg = is_wp_error($res) ? 'license_error=' . urlencode($res->get_error_message()) : 'license_ok=1';
        wp_redirect(admin_url('admin.php?page=aics-license&' . $arg)); exit;
    }

    private function header($title) {
        echo '<div class="wrap aics-wrap"><div class="aics-hero"><div><h1>' . esc_html($title) . '</h1><p>AI Content Studio for WordPress v' . esc_html(AICS_VERSION) . ' — генерація SEO-кластерів, фото, FAQ, Schema, Rank Math/Yoast.</p></div><div><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=aics-generator')) . '">🚀 Генерувати</a></div></div>';
    }
    private function footer() { echo '</div>'; }

    public function page_dashboard() {
        $this->header('AI Content Studio');
        $total = intval(get_option('aics_total_generated', 0));
        $remaining = $this->license->remaining_free();
        echo '<div class="aics-grid"><div class="aics-card"><h2>Статус</h2><p class="aics-big">' . esc_html($total) . '</p><p>Згенеровано статей. Безкоштовний ліміт: ' . esc_html(get_option('aics_free_limit', 20)) . '. Залишилось: ' . esc_html($remaining) . '</p></div>';
        echo '<div class="aics-card"><h2>Що вміє версія 3.1</h2><ul><li>AI структура перед написанням</li><li>Природні унікальні тексти без типового ChatGPT стилю</li><li>Pexels → Pixabay → Unsplash без випадкових фото</li><li>ALT, Title, Caption, стиснення фото</li><li>FAQ + Schema.org</li><li>Rank Math + Yoast SEO</li><li>Внутрішня перелінковка серії</li><li>Таблиці, списки, плюси/мінуси, TOC</li></ul></div>';
        echo '<div class="aics-card"><h2>Рекомендована ціна</h2><p><strong>' . esc_html(get_option('aics_price_hint')) . '</strong></p><p>Для старту можна продавати Pro за $79 або 2999 грн. Free: 20 статей. Ліцензія: до 3 доменів, localhost не рахується.</p></div></div>';
        $this->footer();
    }

    public function page_generator() {
        $this->header('Генератор');
        $categories = get_categories(array('hide_empty'=>false));
        ?>
        <div class="aics-card">
            <form id="aics-generate-form">
                <div class="aics-row"><label>Тема / ніша</label><input type="text" name="topic" required placeholder="наприклад: жіноча білизна, сімейний бюджет, WordPress SEO"></div>
                <div class="aics-cols">
                    <div class="aics-row"><label>Кількість статей</label><input type="number" name="count" min="1" max="50" value="3"></div>
                    <div class="aics-row"><label>Слів у статті</label><input type="number" name="words" min="500" max="2500" value="900"></div>
                    <div class="aics-row"><label>Статус</label><select name="post_status"><option value="draft">Чернетка</option><option value="pending">На затвердження</option><option value="publish">Опублікувати</option></select></div>
                    <div class="aics-row"><label>Категорія</label><select name="category_id"><option value="0">Автоматично</option><?php foreach ($categories as $cat) : ?><option value="<?php echo esc_attr($cat->term_id); ?>"><?php echo esc_html($cat->name); ?></option><?php endforeach; ?></select></div>
                </div>
                <div class="aics-checks">
                    <label><input type="checkbox" name="images" value="1" checked> Головне фото</label>
                    <label><input type="checkbox" name="inline_images" value="1" checked> 2 фото в статтю</label>
                    <label><input type="checkbox" name="seo" value="1" checked> SEO Rank Math / Yoast</label>
                    <label><input type="checkbox" name="faq" value="1" checked> FAQ</label>
                    <label><input type="checkbox" name="schema" value="1" checked> Schema.org</label>
                    <label><input type="checkbox" name="links" value="1" checked> Внутрішня перелінковка</label>
                    <label><input type="checkbox" name="quality" value="1" checked> Перевірка якості</label>
                    <label><input type="checkbox" name="toc" value="1" checked> Зміст статті</label>
                </div>
                <button type="submit" class="button button-primary button-hero">🚀 Створити контент-серію</button>
            </form>
            <div id="aics-progress" class="aics-progress" style="display:none"><div></div></div>
            <div id="aics-results" class="aics-results"></div>
        </div>
        <?php $this->footer();
    }

    public function page_settings() {
        $this->header('Налаштування');
        if (isset($_GET['saved'])) echo '<div class="notice notice-success"><p>Налаштування збережено.</p></div>';
        $categories = get_categories(array('hide_empty'=>false));
        ?>
        <form method="post" class="aics-card">
            <?php wp_nonce_field('aics_save_settings'); ?><input type="hidden" name="aics_save_settings" value="1">
            <h2>AI</h2>
            <div class="aics-row"><label>Groq API Key</label><input type="password" name="aics_groq_key" value="<?php echo esc_attr(get_option('aics_groq_key')); ?>"><p class="description">Безкоштовно: console.groq.com</p></div>
            <div class="aics-row"><label>Groq model</label><input type="text" name="aics_groq_model" value="<?php echo esc_attr(get_option('aics_groq_model')); ?>"></div>
            <h2>Фото API</h2>
            <div class="aics-row"><label>Pexels API Key</label><input type="password" name="aics_pexels_key" value="<?php echo esc_attr(get_option('aics_pexels_key')); ?>"><p class="description">Рекомендовано. Безкоштовно: pexels.com/api</p></div>
            <div class="aics-row"><label>Pixabay API Key</label><input type="password" name="aics_pixabay_key" value="<?php echo esc_attr(get_option('aics_pixabay_key')); ?>"><p class="description">Запасне джерело. Безкоштовно: pixabay.com/api/docs</p></div>
            <div class="aics-row"><label>Unsplash Access Key</label><input type="password" name="aics_unsplash_key" value="<?php echo esc_attr(get_option('aics_unsplash_key')); ?>"><p class="description">Третій резерв. Безкоштовно: unsplash.com/developers</p></div>
            <div class="aics-row"><label>Порядок джерел</label><input type="text" name="aics_image_provider_order" value="<?php echo esc_attr(get_option('aics_image_provider_order')); ?>"></div>
            <h2>Публікація</h2>
            <div class="aics-row"><label>Категорія за замовчуванням</label><select name="aics_default_category"><option value="0">Автоматично</option><?php foreach ($categories as $cat) : ?><option value="<?php echo esc_attr($cat->term_id); ?>" <?php selected(get_option('aics_default_category'), $cat->term_id); ?>><?php echo esc_html($cat->name); ?></option><?php endforeach; ?></select></div>
            <div class="aics-row"><label>Статус за замовчуванням</label><select name="aics_post_status"><option value="draft" <?php selected(get_option('aics_post_status'), 'draft'); ?>>Чернетка</option><option value="pending" <?php selected(get_option('aics_post_status'), 'pending'); ?>>На затвердження</option><option value="publish" <?php selected(get_option('aics_post_status'), 'publish'); ?>>Опублікувати</option></select></div>
            <label><input type="checkbox" name="aics_auto_categories" value="1" <?php checked(get_option('aics_auto_categories'), 1); ?>> Автоматично створювати категорії</label>
            <h2>Монетизація / оновлення</h2>
            <div class="aics-row"><label>Payhip URL</label><input type="url" name="aics_payhip_url" value="<?php echo esc_attr(get_option('aics_payhip_url')); ?>"></div>
            <div class="aics-row"><label>Підказка ціни</label><input type="text" name="aics_price_hint" value="<?php echo esc_attr(get_option('aics_price_hint')); ?>"></div>
            <div class="aics-row"><label>Free limit</label><input type="number" name="aics_free_limit" value="<?php echo esc_attr(get_option('aics_free_limit',20)); ?>"></div>
            <div class="aics-row"><label>Доменів у ліцензії</label><input type="number" name="aics_license_domains_limit" value="<?php echo esc_attr(get_option('aics_license_domains_limit',3)); ?>"><p class="description">localhost не враховується. Повний контроль між різними сайтами потребує окремого license-сервера, але логіка в плагіні вже закладена.</p></div>
            <div class="aics-row"><label>GitHub repo</label><input type="text" name="aics_github_repo" value="<?php echo esc_attr(get_option('aics_github_repo')); ?>"></div>
            <button class="button button-primary">Зберегти</button> <button type="button" id="aics-test-api" class="button">Перевірити Groq</button>
        </form>
        <?php $this->footer();
    }

    public function page_license() {
        $this->header('Ліцензія');
        if (isset($_GET['license_ok'])) echo '<div class="notice notice-success"><p>Ліцензію активовано.</p></div>';
        if (isset($_GET['license_error'])) echo '<div class="notice notice-error"><p>' . esc_html(wp_unslash($_GET['license_error'])) . '</p></div>';
        $domains = get_option('aics_license_domains', array()); if (!is_array($domains)) $domains = array();
        ?>
        <div class="aics-grid"><div class="aics-card"><h2>Поточний статус</h2><p><strong><?php echo $this->license->is_valid() ? 'Pro активний' : 'Free'; ?></strong></p><p>Поточний домен: <?php echo esc_html(AICS_Utils::current_host()); ?><?php echo AICS_Utils::is_local_host() ? ' (localhost не рахується)' : ''; ?></p><p>Залишилось безкоштовних статей: <?php echo esc_html($this->license->remaining_free()); ?></p></div><div class="aics-card"><h2>Активувати</h2><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><?php wp_nonce_field('aics_license'); ?><input type="hidden" name="action" value="aics_activate_license"><input type="text" name="license_key" style="width:100%" placeholder="Вставте ключ з Payhip"><p><button class="button button-primary">Активувати</button></p></form><p><a class="button" target="_blank" href="<?php echo esc_url(get_option('aics_payhip_url')); ?>">Купити на Payhip</a></p></div></div>
        <div class="aics-card"><h2>Прив’язані домени</h2><p><?php echo $domains ? esc_html(implode(', ', $domains)) : 'Поки немає.'; ?></p></div>
        <?php $this->footer();
    }

    public function page_logs() {
        global $wpdb;
        $this->header('Журнал');
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}aics_logs ORDER BY id DESC LIMIT 100");
        echo '<div class="aics-card"><table class="widefat"><thead><tr><th>Дата</th><th>Рівень</th><th>Дія</th><th>Повідомлення</th></tr></thead><tbody>';
        foreach ($rows as $r) echo '<tr><td>' . esc_html($r->created_at) . '</td><td>' . esc_html($r->level) . '</td><td>' . esc_html($r->action) . '</td><td>' . esc_html($r->message) . '</td></tr>';
        if (!$rows) echo '<tr><td colspan="4">Журнал порожній.</td></tr>';
        echo '</tbody></table></div>';
        $this->footer();
    }
}
