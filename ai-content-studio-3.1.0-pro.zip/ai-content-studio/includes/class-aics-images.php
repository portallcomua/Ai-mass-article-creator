<?php
if (!defined('ABSPATH')) exit;

class AICS_Images {
    private $ai;
    public function __construct($ai) { $this->ai = $ai; }

    public function build_query($title, $topic) {
        $src = mb_strtolower($topic . ' ' . $title, 'UTF-8');
        $map = array(
            'жіноча білизна'=>'women lingerie fashion','нижня білизна'=>'women lingerie fashion','білизна'=>'lingerie fashion','бюстгальтер'=>'bra lingerie','трусики'=>'panties lingerie','піжама'=>'pajamas sleepwear','купальник'=>'swimsuit beachwear','корсет'=>'corset fashion','панчохи'=>'stockings fashion','одяг'=>'fashion clothing',
            'сімейний бюджет'=>'family budget finance','бюджет'=>'personal finance budget','фінанси'=>'personal finance','гроші'=>'money finance','економія'=>'saving money','заробіток'=>'online income business',
            'бізнес'=>'business office','маркетинг'=>'digital marketing','seo'=>'seo marketing','wordpress'=>'wordpress website','сайт'=>'website design','сервер'=>'server room technology','хостинг'=>'web hosting server','карта'=>'map navigation','google maps'=>'map navigation'
        );
        foreach ($map as $ua => $en) if (mb_strpos($src, $ua) !== false) return $en;
        $ai_query = $this->ai->has_key() ? $this->ai->image_query($title, $topic) : '';
        if ($ai_query) return $ai_query;
        return 'professional lifestyle';
    }

    public function find_image($query) {
        $order = array_map('trim', explode(',', get_option('aics_image_provider_order', 'pexels,pixabay,unsplash')));
        foreach ($order as $provider) {
            $method = 'search_' . sanitize_key($provider);
            if (method_exists($this, $method)) {
                $url = $this->{$method}($query);
                if ($url) return array('url'=>$url,'provider'=>$provider,'query'=>$query);
            }
        }
        return false;
    }

    private function search_pexels($query) {
        $key = get_option('aics_pexels_key', '');
        if (!$key) return false;
        $url = add_query_arg(array('query'=>$query,'orientation'=>'landscape','per_page'=>10,'size'=>'large','locale'=>'en-US'), 'https://api.pexels.com/v1/search');
        $res = wp_remote_get($url, array('timeout'=>20,'headers'=>array('Authorization'=>$key)));
        if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) return false;
        $data = json_decode(wp_remote_retrieve_body($res), true);
        if (empty($data['photos'])) return false;
        foreach ($data['photos'] as $photo) {
            if (!empty($photo['src']['large2x'])) return esc_url_raw($photo['src']['large2x']);
            if (!empty($photo['src']['large'])) return esc_url_raw($photo['src']['large']);
        }
        return false;
    }

    private function search_pixabay($query) {
        $key = get_option('aics_pixabay_key', '');
        if (!$key) return false;
        $url = add_query_arg(array('key'=>$key,'q'=>$query,'image_type'=>'photo','orientation'=>'horizontal','safesearch'=>'true','per_page'=>10,'lang'=>'en'), 'https://pixabay.com/api/');
        $res = wp_remote_get($url, array('timeout'=>20));
        if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) return false;
        $data = json_decode(wp_remote_retrieve_body($res), true);
        if (empty($data['hits'])) return false;
        foreach ($data['hits'] as $hit) {
            if (!empty($hit['largeImageURL'])) return esc_url_raw($hit['largeImageURL']);
            if (!empty($hit['webformatURL'])) return esc_url_raw($hit['webformatURL']);
        }
        return false;
    }

    private function search_unsplash($query) {
        $key = get_option('aics_unsplash_key', '');
        if (!$key) return false;
        $url = add_query_arg(array('query'=>$query,'orientation'=>'landscape','content_filter'=>'high','client_id'=>$key), 'https://api.unsplash.com/photos/random');
        $res = wp_remote_get($url, array('timeout'=>20));
        if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) return false;
        $data = json_decode(wp_remote_retrieve_body($res), true);
        if (!empty($data['urls']['regular'])) return esc_url_raw($data['urls']['regular']);
        return false;
    }

    public function sideload($post_id, $image_url, $title, $caption = '', $featured = false) {
        if (!$image_url) return false;
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $tmp = download_url($image_url, 30);
        if (is_wp_error($tmp)) return false;
        $file = array('name'=>sanitize_title($title) . '-' . time() . '-' . mt_rand(100,999) . '.jpg','tmp_name'=>$tmp);
        $aid = media_handle_sideload($file, $post_id, $caption);
        if (is_wp_error($aid)) { @unlink($tmp); return false; }
        wp_update_post(array('ID'=>$aid,'post_title'=>sanitize_text_field($title),'post_excerpt'=>sanitize_text_field($caption),'post_content'=>sanitize_text_field($caption)));
        update_post_meta($aid, '_wp_attachment_image_alt', sanitize_text_field($title));
        $this->optimize_attachment($aid);
        if ($featured) set_post_thumbnail($post_id, $aid);
        return $aid;
    }

    private function optimize_attachment($attachment_id) {
        $path = get_attached_file($attachment_id);
        if (!$path || !file_exists($path)) return;
        $editor = wp_get_image_editor($path);
        if (is_wp_error($editor)) return;
        $size = $editor->get_size();
        if (!empty($size['width']) && $size['width'] > 1600) $editor->resize(1600, null, false);
        if (method_exists($editor, 'set_quality')) $editor->set_quality(82);
        $editor->save($path);
        wp_update_attachment_metadata($attachment_id, wp_generate_attachment_metadata($attachment_id, $path));
    }

    public function add_featured($post_id, $title, $topic) {
        $query = $this->build_query($title, $topic);
        $found = $this->find_image($query);
        if (!$found) return false;
        $caption = sprintf('Фото до матеріалу: %s', $title);
        $aid = $this->sideload($post_id, $found['url'], $title, $caption, true);
        if ($aid) update_post_meta($post_id, '_aics_featured_image_provider', $found['provider']);
        return (bool) $aid;
    }

    public function add_inline($post_id, $title, $topic, $count = 2) {
        $content = get_post_field('post_content', $post_id);
        $parts = explode('</p>', $content);
        if (count($parts) < 4) return 0;
        $positions = array();
        for ($i=1; $i<=$count; $i++) {
            $pos = (int) round((count($parts) / ($count + 1)) * $i);
            if ($pos > 0 && $pos < count($parts)) $positions[] = $pos;
        }
        $positions = array_unique(array_reverse($positions));
        $added = 0;
        foreach ($positions as $pos) {
            $query = $this->build_query($title, $topic);
            $found = $this->find_image($query);
            if (!$found) continue;
            $caption = sprintf('%s — тематичне зображення', $title);
            $aid = $this->sideload($post_id, $found['url'], $title, $caption, false);
            if (!$aid) continue;
            $url = wp_get_attachment_image_url($aid, 'large');
            if (!$url) continue;
            $html = '</p><figure class="aics-inline-image"><img src="' . esc_url($url) . '" alt="' . esc_attr($title) . '" loading="lazy" style="width:100%;height:auto;border-radius:10px"><figcaption>' . esc_html($caption) . '</figcaption></figure>';
            $parts[$pos - 1] .= $html;
            $added++;
        }
        if ($added) wp_update_post(array('ID'=>$post_id,'post_content'=>implode('', $parts)));
        return $added;
    }
}
