<?php
if (!defined('ABSPATH')) exit;

class AICS_SEO {
    private $ai;
    public function __construct($ai) { $this->ai = $ai; }

    public function generate_meta($title, $topic, $content) {
        $prompt = "For this Ukrainian SEO article create metadata. Return JSON with keys: focus_keywords (array of 5 strings), meta_title (max 60 chars), meta_description (max 155 chars), tags (array of 8 Ukrainian tags), category (short Ukrainian category name). Title: {$title}. Topic: {$topic}. Text: " . AICS_Utils::excerpt($content, 1500);
        $data = $this->ai->json($prompt, 900);
        if (is_wp_error($data)) {
            return array('focus_keywords'=>array($topic),'meta_title'=>AICS_Utils::excerpt($title,60),'meta_description'=>AICS_Utils::excerpt($content,155),'tags'=>array($topic),'category'=>$topic);
        }
        return wp_parse_args($data, array('focus_keywords'=>array($topic),'meta_title'=>$title,'meta_description'=>AICS_Utils::excerpt($content,155),'tags'=>array($topic),'category'=>$topic));
    }

    public function apply($post_id, $meta) {
        $keywords = !empty($meta['focus_keywords']) && is_array($meta['focus_keywords']) ? array_map('sanitize_text_field', $meta['focus_keywords']) : array();
        $tags = !empty($meta['tags']) && is_array($meta['tags']) ? array_map('sanitize_text_field', $meta['tags']) : $keywords;
        $description = !empty($meta['meta_description']) ? AICS_Utils::excerpt($meta['meta_description'], 155) : '';
        $meta_title = !empty($meta['meta_title']) ? AICS_Utils::excerpt($meta['meta_title'], 60) : get_the_title($post_id);
        if ($tags) wp_set_post_tags($post_id, $tags, false);
        if ($keywords) {
            $focus = implode(', ', array_slice($keywords, 0, 5));
            update_post_meta($post_id, 'rank_math_focus_keyword', $focus);
            update_post_meta($post_id, '_yoast_wpseo_focuskw', $keywords[0]);
            update_post_meta($post_id, '_aics_keywords', $focus);
        }
        update_post_meta($post_id, 'rank_math_title', $meta_title);
        update_post_meta($post_id, '_yoast_wpseo_title', $meta_title);
        update_post_meta($post_id, 'rank_math_description', $description);
        update_post_meta($post_id, '_yoast_wpseo_metadesc', $description);
        update_post_meta($post_id, '_aics_description', $description);
    }

    public function ensure_category($name, $fallback_id = 0) {
        if (!get_option('aics_auto_categories', 1)) return intval($fallback_id);
        $name = sanitize_text_field($name);
        if (!$name) return intval($fallback_id);
        $term = term_exists($name, 'category');
        if (!$term) $term = wp_insert_term($name, 'category');
        if (is_wp_error($term)) return intval($fallback_id);
        return intval(is_array($term) ? $term['term_id'] : $term);
    }

    public function schema_article($post_id, $title, $description, $faq = array()) {
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Article',
            'headline' => $title,
            'description' => $description,
            'datePublished' => get_the_date('c', $post_id),
            'dateModified' => get_the_modified_date('c', $post_id),
            'author' => array('@type'=>'Organization','name'=>get_bloginfo('name')),
            'publisher' => array('@type'=>'Organization','name'=>get_bloginfo('name')),
            'mainEntityOfPage' => get_permalink($post_id),
        );
        if (has_post_thumbnail($post_id)) $schema['image'] = get_the_post_thumbnail_url($post_id, 'full');
        update_post_meta($post_id, '_aics_schema_article', wp_json_encode($schema, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        if ($faq) {
            $items = array();
            foreach ($faq as $qa) {
                if (empty($qa['question']) || empty($qa['answer'])) continue;
                $items[] = array('@type'=>'Question','name'=>wp_strip_all_tags($qa['question']),'acceptedAnswer'=>array('@type'=>'Answer','text'=>wp_strip_all_tags($qa['answer'])));
            }
            if ($items) update_post_meta($post_id, '_aics_schema_faq', wp_json_encode(array('@context'=>'https://schema.org','@type'=>'FAQPage','mainEntity'=>$items), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        }
    }

    public function print_schema() {
        if (!is_singular('post')) return;
        $post_id = get_queried_object_id();
        foreach (array('_aics_schema_article','_aics_schema_faq') as $key) {
            $json = get_post_meta($post_id, $key, true);
            if ($json) echo "\n<script type=\"application/ld+json\">" . wp_kses_post($json) . "</script>\n";
        }
    }
}
