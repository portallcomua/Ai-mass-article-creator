<?php
if (!defined('ABSPATH')) exit;

class AICS_Updater {
    public function __construct() {
        add_filter('pre_set_site_transient_update_plugins', array($this, 'check'));
        add_filter('plugins_api', array($this, 'info'), 10, 3);
    }

    private function remote() {
        $repo = get_option('aics_github_repo', 'portallcomua/Ai-mass-article-creator');
        $res = wp_remote_get('https://api.github.com/repos/' . $repo . '/releases/latest', array('timeout'=>15));
        if (is_wp_error($res)) return null;
        $data = json_decode(wp_remote_retrieve_body($res), true);
        if (!empty($data['tag_name']) && !empty($data['zipball_url'])) return (object) array('version'=>ltrim($data['tag_name'], 'v'),'package'=>$data['zipball_url'],'body'=>isset($data['body'])?$data['body']:'');
        return null;
    }

    public function check($transient) {
        if (empty($transient->checked)) return $transient;
        $remote = $this->remote();
        if ($remote && version_compare(AICS_VERSION, $remote->version, '<')) {
            $transient->response[AICS_BASENAME] = (object) array('slug'=>'ai-content-studio','plugin'=>AICS_BASENAME,'new_version'=>$remote->version,'package'=>$remote->package,'tested'=>'6.5');
        }
        return $transient;
    }

    public function info($false, $action, $args) {
        if ($action !== 'plugin_information' || empty($args->slug) || $args->slug !== 'ai-content-studio') return $false;
        $remote = $this->remote();
        if (!$remote) return $false;
        return (object) array('name'=>'AI Content Studio for WordPress','slug'=>'ai-content-studio','version'=>$remote->version,'download_link'=>$remote->package,'requires'=>'5.8','tested'=>'6.5','sections'=>array('description'=>'Professional AI SEO content generator.','changelog'=>wp_kses_post($remote->body)));
    }
}
