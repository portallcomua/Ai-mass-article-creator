<?php
if (!defined('ABSPATH')) exit;

class AICS_License {
    public function is_local() { return AICS_Utils::is_local_host(); }

    public function is_valid() {
        if ($this->is_local()) return true;
        return (bool) get_option('aics_license_valid', false);
    }

    public function can_generate($planned = 1) {
        if ($this->is_valid()) return true;
        $total = intval(get_option('aics_total_generated', 0));
        $limit = intval(get_option('aics_free_limit', 20));
        return ($total + intval($planned)) <= $limit;
    }

    public function remaining_free() {
        if ($this->is_valid()) return 999999;
        return max(0, intval(get_option('aics_free_limit', 20)) - intval(get_option('aics_total_generated', 0)));
    }

    public function activate($key) {
        $key = sanitize_text_field($key);
        if (strlen($key) < 8) return new WP_Error('aics_bad_license', 'Ключ ліцензії занадто короткий.');
        $host = AICS_Utils::current_host();
        $domains = get_option('aics_license_domains', array());
        if (!is_array($domains)) $domains = array();
        if (!AICS_Utils::is_local_host($host) && !in_array($host, $domains, true)) {
            $limit = intval(get_option('aics_license_domains_limit', 3));
            if (count($domains) >= $limit) return new WP_Error('aics_domain_limit', 'Ліміт доменів для цієї ліцензії вичерпано.');
            $domains[] = $host;
        }
        update_option('aics_license_key', $key, false);
        update_option('aics_license_valid', true, false);
        update_option('aics_license_domains', $domains, false);
        return true;
    }
}
