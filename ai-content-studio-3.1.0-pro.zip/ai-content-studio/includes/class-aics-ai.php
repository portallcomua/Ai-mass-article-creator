<?php
if (!defined('ABSPATH')) exit;

class AICS_AI {
    public function has_key() { return !empty(get_option('aics_groq_key', '')); }

    public function complete($prompt, $max_tokens = 2500, $temperature = 0.65) {
        $api_key = get_option('aics_groq_key', '');
        if (empty($api_key)) return new WP_Error('aics_no_key', 'Groq API key is not configured.');
        $model = get_option('aics_groq_model', 'llama-3.1-8b-instant');
        $response = wp_remote_post('https://api.groq.com/openai/v1/chat/completions', array(
            'timeout' => 120,
            'headers' => array('Content-Type'=>'application/json','Authorization'=>'Bearer ' . $api_key),
            'body' => wp_json_encode(array(
                'model' => $model,
                'messages' => array(
                    array('role'=>'system','content'=>'You are a senior Ukrainian SEO editor. Write natural, unique, useful, non-generic text. Avoid clichés, filler, repeated phrases and typical AI style.'),
                    array('role'=>'user','content'=>$prompt),
                ),
                'temperature' => $temperature,
                'max_tokens' => $max_tokens,
            )),
        ));
        if (is_wp_error($response)) return $response;
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300) {
            $msg = isset($body['error']['message']) ? $body['error']['message'] : 'Groq API error ' . $code;
            return new WP_Error('aics_api_error', $msg);
        }
        if (empty($body['choices'][0]['message']['content'])) return new WP_Error('aics_empty_ai', 'AI returned empty response.');
        return trim($body['choices'][0]['message']['content']);
    }

    public function json($prompt, $max_tokens = 2000) {
        $raw = $this->complete($prompt . "\n\nReturn valid JSON only. No markdown.", $max_tokens, 0.4);
        if (is_wp_error($raw)) return $raw;
        $raw = preg_replace('/^\s*```(?:json)?\s*/i', '', $raw);
        $raw = preg_replace('/```\s*$/i', '', $raw);
        $data = json_decode($raw, true);
        if (!is_array($data)) return new WP_Error('aics_bad_json', 'AI returned invalid JSON: ' . mb_substr($raw, 0, 300));
        return $data;
    }

    public function image_query($title, $topic) {
        $prompt = "Translate this Ukrainian article topic to a short English stock-photo search query. Return only 2-5 English words, no punctuation. Topic: {$topic}. Article title: {$title}";
        $res = $this->complete($prompt, 40, 0.2);
        if (is_wp_error($res)) return '';
        $res = strtolower(preg_replace('/[^a-zA-Z0-9\s-]/', ' ', $res));
        return trim(preg_replace('/\s+/', ' ', $res));
    }
}
