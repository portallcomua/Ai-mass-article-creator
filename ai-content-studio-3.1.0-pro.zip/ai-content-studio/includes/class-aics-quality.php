<?php
if (!defined('ABSPATH')) exit;

class AICS_Quality {
    public function score($html, $topic = '') {
        $text = trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($html)));
        $words = preg_split('/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY);
        $word_count = count($words);
        $score = 100;
        $notes = array();
        if ($word_count < 450) { $score -= 20; $notes[] = 'Текст короткий.'; }
        if (substr_count($html, '<h2') < 2) { $score -= 10; $notes[] = 'Мало підзаголовків H2.'; }
        if (substr_count($html, '<ul') + substr_count($html, '<ol') < 1) { $score -= 8; $notes[] = 'Немає списків.'; }
        if (substr_count($html, '<table') < 1) { $score -= 5; $notes[] = 'Немає таблиці.'; }
        $generic = array('у сучасному світі','важливо зазначити','слід зазначити','висновок очевидний','на сьогоднішній день');
        foreach ($generic as $phrase) if (mb_stripos($text, $phrase) !== false) { $score -= 5; $notes[] = 'Є шаблонні фрази.'; break; }
        if ($topic && mb_stripos($text, $topic) === false) { $score -= 10; $notes[] = 'Тема майже не згадується.'; }
        $score = max(0, min(100, $score));
        if (!$notes) $notes[] = 'Якість базово добра.';
        return array('score'=>$score,'word_count'=>$word_count,'notes'=>$notes);
    }
}
