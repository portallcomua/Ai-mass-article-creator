<?php
if (!defined('ABSPATH')) exit;

class AICS_Generator {
    private $ai; private $images; private $seo; private $quality; private $license;
    public function __construct($ai, $images, $seo, $quality, $license) {
        $this->ai = $ai; $this->images = $images; $this->seo = $seo; $this->quality = $quality; $this->license = $license;
        add_action('wp_ajax_aics_generate', array($this, 'ajax_generate'));
        add_action('wp_ajax_aics_test_api', array($this, 'ajax_test_api'));
    }

    public function ajax_test_api() {
        check_ajax_referer('aics_admin', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(array('message'=>'Недостатньо прав.'));
        $res = $this->ai->complete('Reply only: OK', 10, 0.1);
        if (is_wp_error($res)) wp_send_json_error(array('message'=>$res->get_error_message()));
        wp_send_json_success(array('message'=>'Groq API працює.'));
    }

    public function ajax_generate() {
        check_ajax_referer('aics_admin', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(array('message'=>'Недостатньо прав.'));
        $topic = isset($_POST['topic']) ? sanitize_text_field(wp_unslash($_POST['topic'])) : '';
        $count = isset($_POST['count']) ? max(1, min(50, intval($_POST['count']))) : 1;
        $words = isset($_POST['words']) ? max(500, min(2500, intval($_POST['words']))) : 900;
        $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : intval(get_option('aics_default_category', 0));
        $status = isset($_POST['post_status']) ? sanitize_key($_POST['post_status']) : get_option('aics_post_status', 'draft');
        if (!in_array($status, array('draft','pending','publish'), true)) $status = 'draft';
        if (!$topic) wp_send_json_error(array('message'=>'Введіть тему.'));
        if (!$this->ai->has_key()) wp_send_json_error(array('message'=>'Спочатку вкажіть Groq API Key у налаштуваннях.'));
        if (!$this->license->can_generate($count)) wp_send_json_error(array('message'=>'Безкоштовний ліміт 20 статей вичерпано. Активуйте ліцензію.'));

        $features = array(
            'images'=>!empty($_POST['images']), 'inline_images'=>!empty($_POST['inline_images']), 'faq'=>!empty($_POST['faq']), 'schema'=>!empty($_POST['schema']),
            'seo'=>!empty($_POST['seo']), 'links'=>!empty($_POST['links']), 'quality'=>!empty($_POST['quality']), 'toc'=>!empty($_POST['toc'])
        );
        $result = $this->generate_series($topic, $count, $words, $category_id, $status, $features);
        if (is_wp_error($result)) wp_send_json_error(array('message'=>$result->get_error_message()));
        wp_send_json_success($result);
    }

    public function generate_series($topic, $count, $words, $category_id, $status, $features) {
        AICS_Utils::log('info', 'generate_start', 'Generation started', compact('topic','count','words'));
        $plan = $this->plan_series($topic, $count);
        if (is_wp_error($plan)) return $plan;
        $created = array();
        foreach ($plan as $item) {
            $post = $this->generate_one($topic, $item, $words, $category_id, $status, $features);
            if (!is_wp_error($post)) $created[] = $post;
        }
        if (!empty($features['links']) && count($created) > 1) $this->link_created_posts($created);
        update_option('aics_total_generated', intval(get_option('aics_total_generated', 0)) + count($created));
        AICS_Utils::log('info', 'generate_done', 'Generation finished', array('created'=>count($created)));
        return array('message'=>sprintf('Створено %d матеріалів.', count($created)), 'posts'=>$created, 'remaining'=>$this->license->remaining_free());
    }

    private function plan_series($topic, $count) {
        if ($count === 1) return array(array('title'=>$topic, 'intent'=>'Корисна SEO-стаття', 'category'=>$topic));
        $prompt = "Create a Ukrainian SEO content cluster plan for topic '{$topic}'. Need exactly {$count} articles. Return JSON array. Each item: title, intent, category, focus_keywords array. Titles must be unique, useful and not clickbait.";
        $data = $this->ai->json($prompt, 1800);
        if (is_wp_error($data) || !is_array($data)) {
            $items = array();
            for ($i=1; $i<=$count; $i++) $items[] = array('title'=>$topic . ' — матеріал ' . $i, 'intent'=>'SEO article', 'category'=>$topic);
            return $items;
        }
        $items = array();
        foreach ($data as $row) {
            if (!empty($row['title'])) $items[] = $row;
            if (count($items) >= $count) break;
        }
        while (count($items) < $count) $items[] = array('title'=>$topic . ' — корисні поради #' . (count($items)+1), 'intent'=>'SEO article', 'category'=>$topic);
        return $items;
    }

    private function generate_one($topic, $item, $words, $category_id, $status, $features) {
        $title = sanitize_text_field($item['title']);
        $outline = $this->outline($title, $topic, $item);
        $content = $this->article($title, $topic, $outline, $words);
        if (is_wp_error($content)) { AICS_Utils::log('error','article_failed',$content->get_error_message(),array('title'=>$title)); return $content; }
        if (!empty($features['toc'])) $content = $this->add_toc($content);
        $faq = !empty($features['faq']) ? $this->faq($title, $topic, $content) : array();
        if ($faq) $content .= $this->faq_html($faq);
        $meta = !empty($features['seo']) ? $this->seo->generate_meta($title, $topic, $content) : array('category'=>isset($item['category'])?$item['category']:$topic);
        $cat = $this->seo->ensure_category(isset($meta['category'])?$meta['category']:$topic, $category_id);
        $post_id = wp_insert_post(array('post_title'=>$title,'post_content'=>$content,'post_status'=>$status,'post_type'=>'post','post_category'=>array($cat)));
        if (is_wp_error($post_id) || !$post_id) return new WP_Error('aics_insert_failed', 'Не вдалося створити запис.');
        if (!empty($features['seo'])) $this->seo->apply($post_id, $meta);
        $has_image = false; $inline_count = 0;
        if (!empty($features['images'])) $has_image = $this->images->add_featured($post_id, $title, $topic);
        if (!empty($features['inline_images'])) $inline_count = $this->images->add_inline($post_id, $title, $topic, 2);
        if (!empty($features['schema'])) $this->seo->schema_article($post_id, $title, isset($meta['meta_description'])?$meta['meta_description']:AICS_Utils::excerpt($content,155), $faq);
        $quality = !empty($features['quality']) ? $this->quality->score(get_post_field('post_content', $post_id), $topic) : array('score'=>0,'word_count'=>0,'notes'=>array());
        update_post_meta($post_id, '_aics_quality_score', intval($quality['score']));
        update_post_meta($post_id, '_aics_generation_topic', $topic);
        update_post_meta($post_id, '_aics_version', AICS_VERSION);
        return array('id'=>$post_id,'title'=>$title,'edit_url'=>get_edit_post_link($post_id, 'raw'),'view_url'=>get_permalink($post_id),'quality'=>$quality,'image'=>$has_image,'inline_images'=>$inline_count);
    }

    private function outline($title, $topic, $item) {
        $prompt = "Create a detailed Ukrainian article structure before writing. Topic: {$topic}. Title: {$title}. Intent: " . (isset($item['intent'])?$item['intent']:'') . ". Return clean bullet outline with H2/H3 sections, include FAQ ideas, table idea, pros/cons block idea. No article text.";
        $res = $this->ai->complete($prompt, 900, 0.45);
        return is_wp_error($res) ? '' : $res;
    }

    private function article($title, $topic, $outline, $words) {
        $prompt = "Write a unique, natural Ukrainian SEO article for WordPress.\nTitle: {$title}\nMain topic: {$topic}\nTarget length: {$words} words.\nOutline:\n{$outline}\n\nRequirements:\n- sound like a real Ukrainian editor, not ChatGPT;\n- practical, concrete, useful;\n- no filler and no generic clichés;\n- use HTML only: h2, h3, p, ul, ol, li, strong, em, blockquote, table, thead, tbody, tr, th, td, div;\n- include at least one comparison table;\n- include one pros/cons block using div class=\"aics-pros-cons\";\n- do not include images, scripts, CSS or external links;\n- do not repeat the title as H1;\n- return only article HTML.";
        $res = $this->ai->complete($prompt, 4200, 0.72);
        if (is_wp_error($res)) return $res;
        return AICS_Utils::sanitize_html($res);
    }

    private function faq($title, $topic, $content) {
        $prompt = "Create 5 useful FAQ questions and answers in Ukrainian for this article. Return JSON array with question and answer. Title: {$title}. Topic: {$topic}. Text: " . AICS_Utils::excerpt($content, 1200);
        $data = $this->ai->json($prompt, 1000);
        if (is_wp_error($data) || !is_array($data)) return array();
        return array_slice($data, 0, 5);
    }

    private function faq_html($faq) {
        $html = '<section class="aics-faq"><h2>Питання та відповіді</h2>';
        foreach ($faq as $qa) {
            if (empty($qa['question']) || empty($qa['answer'])) continue;
            $html .= '<h3>' . esc_html($qa['question']) . '</h3><p>' . esc_html($qa['answer']) . '</p>';
        }
        return $html . '</section>';
    }

    private function add_toc($html) {
        preg_match_all('/<h2[^>]*>(.*?)<\/h2>/is', $html, $m);
        if (empty($m[1]) || count($m[1]) < 2) return $html;
        $toc = '<div class="aics-toc"><strong>Зміст</strong><ol>';
        foreach ($m[1] as $i => $heading) {
            $text = wp_strip_all_tags($heading);
            $id = 'aics-' . sanitize_title($text);
            $html = preg_replace('/<h2([^>]*)>' . preg_quote($heading, '/') . '<\/h2>/i', '<h2$1 id="' . esc_attr($id) . '">' . $heading . '</h2>', $html, 1);
            $toc .= '<li><a href="#' . esc_attr($id) . '">' . esc_html($text) . '</a></li>';
        }
        return $toc . '</ol></div>' . $html;
    }

    private function link_created_posts($posts) {
        foreach ($posts as $post) {
            $links = '<div class="aics-related"><h2>Читайте також</h2><ul>';
            $n = 0;
            foreach ($posts as $other) {
                if ($other['id'] == $post['id']) continue;
                $links .= '<li><a href="' . esc_url($other['view_url']) . '">' . esc_html($other['title']) . '</a></li>';
                $n++; if ($n >= intval(get_option('aics_internal_links_count', 3))) break;
            }
            $links .= '</ul></div>';
            $content = get_post_field('post_content', $post['id']);
            wp_update_post(array('ID'=>$post['id'],'post_content'=>$content . $links));
        }
    }
}
