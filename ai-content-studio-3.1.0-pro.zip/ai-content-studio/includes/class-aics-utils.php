<?php
if (!defined('ABSPATH')) exit;

class AICS_Utils {
    public static function defaults() {
        return array(
            'aics_groq_key' => get_option('amac_api_key', ''),
            'aics_groq_model' => 'llama-3.1-8b-instant',
            'aics_pexels_key' => get_option('amac_pexels_key', ''),
            'aics_pixabay_key' => get_option('amac_pixabay_key', ''),
            'aics_unsplash_key' => get_option('amac_unsplash_key', ''),
            'aics_default_category' => intval(get_option('amac_default_category', 0)),
            'aics_total_generated' => intval(get_option('amac_total_generated', 0)),
            'aics_free_limit' => 20,
            'aics_payhip_url' => 'https://payhip.com/b/bw9ly',
            'aics_price_hint' => '$79 Pro / $149 Business / $249 Agency',
            'aics_github_repo' => 'portallcomua/Ai-mass-article-creator',
            'aics_post_status' => 'draft',
            'aics_image_provider_order' => 'pexels,pixabay,unsplash',
            'aics_auto_categories' => 1,
            'aics_quality_threshold' => 70,
            'aics_internal_links_count' => 3,
            'aics_license_domains_limit' => 3,
        );
    }

    public static function set_defaults() {
        foreach (self::defaults() as $key => $value) {
            if (get_option($key, null) === null) add_option($key, $value, '', false);
        }
    }

    public static function migrate_legacy_options() {
        $map = array(
            'amac_api_key' => 'aics_groq_key',
            'amac_pexels_key' => 'aics_pexels_key',
            'amac_pixabay_key' => 'aics_pixabay_key',
            'amac_unsplash_key' => 'aics_unsplash_key',
            'amac_default_category' => 'aics_default_category',
            'amac_total_generated' => 'aics_total_generated',
            'amac_license_key' => 'aics_license_key',
            'amac_license_valid' => 'aics_license_valid',
        );
        foreach ($map as $old => $new) {
            if (get_option($new, null) === null && get_option($old, null) !== null) {
                add_option($new, get_option($old), '', false);
            }
        }
    }

    public static function create_tables() {
        global $wpdb;
        $table = $wpdb->prefix . 'aics_logs';
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            created_at DATETIME NOT NULL,
            level VARCHAR(20) NOT NULL DEFAULT 'info',
            action VARCHAR(80) NOT NULL DEFAULT '',
            message TEXT NULL,
            context LONGTEXT NULL,
            PRIMARY KEY  (id),
            KEY created_at (created_at),
            KEY level (level)
        ) {$charset};";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public static function log($level, $action, $message, $context = array()) {
        global $wpdb;
        $table = $wpdb->prefix . 'aics_logs';
        $wpdb->insert($table, array(
            'created_at' => current_time('mysql'),
            'level' => sanitize_key($level),
            'action' => sanitize_key($action),
            'message' => wp_strip_all_tags($message),
            'context' => wp_json_encode($context),
        ));
    }

    public static function current_host() {
        $host = parse_url(home_url(), PHP_URL_HOST);
        return strtolower($host ? $host : 'localhost');
    }

    public static function is_local_host($host = '') {
        $host = $host ? strtolower($host) : self::current_host();
        return in_array($host, array('localhost','127.0.0.1','::1'), true) || preg_match('/\.(local|test|localhost)$/', $host);
    }

    public static function sanitize_html($html) {
        $html = preg_replace('/^\s*```(?:html)?\s*/i', '', $html);
        $html = preg_replace('/```\s*$/i', '', $html);
        $html = preg_replace('/<script[^>]*>.*?<\/script>/is', '', $html);
        $html = preg_replace('/<style[^>]*>.*?<\/style>/is', '', $html);
        $allowed = array(
            'h2'=>array('id'=>array(),'class'=>array()), 'h3'=>array('id'=>array(),'class'=>array()), 'h4'=>array('id'=>array(),'class'=>array()),
            'p'=>array('class'=>array()), 'ul'=>array('class'=>array()), 'ol'=>array('class'=>array()), 'li'=>array('class'=>array()),
            'strong'=>array(), 'em'=>array(), 'b'=>array(), 'i'=>array(), 'br'=>array(),
            'blockquote'=>array('class'=>array()), 'table'=>array('class'=>array()), 'thead'=>array(), 'tbody'=>array(), 'tr'=>array(), 'th'=>array(), 'td'=>array(),
            'div'=>array('class'=>array()), 'span'=>array('class'=>array()), 'a'=>array('href'=>array(),'title'=>array(),'target'=>array(),'rel'=>array()),
        );
        return wp_kses(trim($html), $allowed);
    }

    public static function excerpt($text, $chars = 155) {
        $text = trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($text)));
        if (mb_strlen($text) <= $chars) return $text;
        return rtrim(mb_substr($text, 0, $chars - 1), ' .,;:-') . '…';
    }
}
