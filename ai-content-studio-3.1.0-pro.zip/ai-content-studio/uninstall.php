<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
// Data is intentionally preserved. Remove options manually only if you really want to reset the plugin.
