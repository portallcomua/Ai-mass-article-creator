<?php
/**
 * Plugin Name: AI Content Studio for WordPress
 * Plugin URI: https://github.com/portallcomua/Ai-mass-article-creator
 * Description: Professional AI content studio: article clusters, natural Ukrainian SEO texts, thematic free images, FAQ, Schema, Rank Math/Yoast SEO, internal linking and Payhip-ready licensing.
 * Version: 3.1.0
 * Author: UAServer
 * Author URI: https://uaserver.pp.ua
 * License: GPL v2 or later
 * Requires PHP: 7.4
 * Requires at least: 5.8
 * Tested up to: 6.5
 * Text Domain: ai-content-studio
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) exit;

define('AICS_VERSION', '3.1.0');
define('AICS_FILE', __FILE__);
define('AICS_DIR', plugin_dir_path(__FILE__));
define('AICS_URL', plugin_dir_url(__FILE__));
define('AICS_BASENAME', plugin_basename(__FILE__));

require_once AICS_DIR . 'includes/class-aics-utils.php';
require_once AICS_DIR . 'includes/class-aics-ai.php';
require_once AICS_DIR . 'includes/class-aics-images.php';
require_once AICS_DIR . 'includes/class-aics-seo.php';
require_once AICS_DIR . 'includes/class-aics-quality.php';
require_once AICS_DIR . 'includes/class-aics-license.php';
require_once AICS_DIR . 'includes/class-aics-generator.php';
require_once AICS_DIR . 'includes/class-aics-updater.php';
require_once AICS_DIR . 'admin/class-aics-admin.php';

final class AI_Content_Studio_Plugin {
    private static $instance = null;
    public $ai;
    public $images;
    public $seo;
    public $quality;
    public $license;
    public $generator;
    public $updater;
    public $admin;

    public static function instance() {
        if (self::$instance === null) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $this->ai = new AICS_AI();
        $this->images = new AICS_Images($this->ai);
        $this->seo = new AICS_SEO($this->ai);
        $this->quality = new AICS_Quality();
        $this->license = new AICS_License();
        $this->generator = new AICS_Generator($this->ai, $this->images, $this->seo, $this->quality, $this->license);
        $this->updater = new AICS_Updater();
        $this->admin = new AICS_Admin($this->generator, $this->license);

        add_action('init', array($this, 'load_textdomain'));
        add_action('wp_head', array($this->seo, 'print_schema'), 30);
    }

    public function load_textdomain() {
        load_plugin_textdomain('ai-content-studio', false, dirname(AICS_BASENAME) . '/languages');
    }

    public static function activate() {
        AICS_Utils::migrate_legacy_options();
        AICS_Utils::set_defaults();
        AICS_Utils::create_tables();
        update_option('aics_version', AICS_VERSION);
    }

    public static function deactivate() {}
}

register_activation_hook(__FILE__, array('AI_Content_Studio_Plugin', 'activate'));
register_deactivation_hook(__FILE__, array('AI_Content_Studio_Plugin', 'deactivate'));

AI_Content_Studio_Plugin::instance();
