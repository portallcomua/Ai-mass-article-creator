# AI Content Studio for WordPress

## 3.1.0
- New professional architecture and branding.
- Article series / content cluster generator.
- Outline generated before article writing.
- Natural Ukrainian editor-style prompt to reduce typical AI tone.
- Pexels → Pixabay → Unsplash image search without random fallback.
- AI/dictionary-based English image query creation.
- Featured image and inline images with ALT, title, captions.
- Basic image optimization.
- Rank Math and Yoast SEO metadata.
- FAQ block and FAQ Schema.
- Article JSON-LD Schema.
- Internal linking between generated articles.
- Tables, pros/cons block, TOC.
- Quality score.
- Free limit: 20 articles.
- Payhip-ready licensing with 3-domain concept; localhost is ignored.
- GitHub release updater.
