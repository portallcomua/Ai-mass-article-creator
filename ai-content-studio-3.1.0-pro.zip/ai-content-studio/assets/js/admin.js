jQuery(function($){
  $('#aics-test-api').on('click',function(){
    var btn=$(this); btn.prop('disabled',true).text('Перевіряю...');
    $.post(AICS.ajax,{action:'aics_test_api',nonce:AICS.nonce},function(r){
      alert(r.success?r.data.message:r.data.message); btn.prop('disabled',false).text('Перевірити Groq');
    });
  });
  $('#aics-generate-form').on('submit',function(e){
    e.preventDefault();
    var box=$('#aics-results'), bar=$('#aics-progress'), fill=$('#aics-progress div');
    box.show().html('<p>🚀 Старт генерації. Не закривайте сторінку...</p>'); bar.show(); fill.css('width','20%');
    var data=$(this).serializeArray(); data.push({name:'action',value:'aics_generate'}); data.push({name:'nonce',value:AICS.nonce});
    $.ajax({url:AICS.ajax,type:'POST',data:data,timeout:300000,success:function(r){
      fill.css('width','100%');
      if(!r.success){box.append('<p style="color:#f87171">❌ '+r.data.message+'</p>');return;}
      var html='<p style="color:#86efac">✅ '+r.data.message+'</p><table><thead><tr><th>#</th><th>Назва</th><th>Якість</th><th>Фото</th><th>Дії</th></tr></thead><tbody>';
      $.each(r.data.posts,function(i,p){html+='<tr><td>'+(i+1)+'</td><td>'+p.title+'</td><td>'+(p.quality?p.quality.score:'-')+'/100</td><td>'+(p.image?'✅':'❌')+'</td><td><a target="_blank" href="'+p.edit_url+'">Редагувати</a> | <a target="_blank" href="'+p.view_url+'">Перегляд</a></td></tr>';});
      html+='</tbody></table><p>Залишилось безкоштовних: '+r.data.remaining+'</p>'; box.append(html);
    },error:function(xhr,status){fill.css('width','5%'); box.append('<p style="color:#f87171">❌ Помилка AJAX: '+status+'. Для великих серій спробуйте 1-3 статті за раз.</p>');}});
  });
});
